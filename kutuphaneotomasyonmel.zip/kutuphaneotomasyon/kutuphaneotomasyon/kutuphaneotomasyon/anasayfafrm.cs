﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kutuphaneotomasyon
{
    public partial class anasayfafrm : Form
    {
        public anasayfafrm()
        {
            InitializeComponent();
        }

        private void anasayfafrm_Load(object sender, EventArgs e)
        {

        }

        private void btnUyeEkle_Click(object sender, EventArgs e)
        {
            UyeEkleFrm uyeekle = new UyeEkleFrm();
            uyeekle.ShowDialog();
        }

        private void btnUyeList_Click(object sender, EventArgs e)
        {
            ÜyeListFrm üyelist = new ÜyeListFrm();
            üyelist.ShowDialog();
        }

        private void btnKitapEkle_Click(object sender, EventArgs e)
        {
            KitapEkleFrm KitaplEkle = new KitapEkleFrm();
            KitaplEkle.ShowDialog();
        }

        private void btnKitapList_Click(object sender, EventArgs e)
        {
            KitapListFrm KitapList = new KitapListFrm();
            KitapList.ShowDialog();
        }
    }
}
