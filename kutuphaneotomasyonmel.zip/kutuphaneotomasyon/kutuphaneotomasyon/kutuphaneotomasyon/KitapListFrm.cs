﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kutuphaneotomasyon
{
    public partial class KitapListFrm : Form
    {
        public KitapListFrm()
        {
            InitializeComponent();
        }

        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-F6GITKL\\SQLEXPRESS;Initial Catalog=KütüphaneOtomasyon;Integrated Security=True");
        DataSet daset = new DataSet();
        private void KitapList()
        {
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select * from kitap ", baglanti);
            adtr.Fill(daset, "kitap");
            dataGridView1.DataSource = daset.Tables["kitap"];
            baglanti.Close();
        }

        private void btnKitapGuncelle_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("update kitap set barkodno = @barkodno, kitapadı = @kitapadı, yazar = @yazar, yayınevi = @yayınevi, sayfasayı = @sayfasayı, türü = @türü, stok = @stok, rafno = @rafno", baglanti);
            komut.Parameters.AddWithValue("@barkodno", txtBarkod.Text);
            komut.Parameters.AddWithValue("@kitapadı", txtKitapAd.Text);
            komut.Parameters.AddWithValue("@yazar", txtYazar.Text);
            komut.Parameters.AddWithValue("@yayınevi", txtEv.Text);
            komut.Parameters.AddWithValue("@sayfasayı", txtSayfa.Text);
            komut.Parameters.AddWithValue("@türü", comboTür.Text);
            komut.Parameters.AddWithValue("@stok", txtStok.Text);
            komut.Parameters.AddWithValue("@rafno", txtRaf.Text);
            komut.ExecuteNonQuery();
            baglanti.Close();
            MessageBox.Show("Güncelleme İşlemi Başarılı!");
            daset.Tables["kitap"].Clear();
            KitapList();
            foreach (Control item in Controls)
            {
                if (item is TextBox)
                {
                    item.Text = "";
                }
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            txtBarkod.Text = dataGridView1.CurrentRow.Cells["barkodno"].Value.ToString();
        }

        private void KitapListFrm_Load(object sender, EventArgs e)
        {
            KitapList();
        }

        private void btnKitapSil_Click(object sender, EventArgs e)
        {
            DialogResult dialog;
            dialog = MessageBox.Show("Kaydı Silmek İstediğinize Eminmisiniz?","Sil",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if (dialog == DialogResult.Yes)
            {
                baglanti.Open();
                SqlCommand komut = new SqlCommand("delete from kitap where barkodno=@barkodno", baglanti);
                komut.Parameters.AddWithValue("@barkodno", dataGridView1.CurrentRow.Cells["barkodno"].Value.ToString());
                komut.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("Silme İşlemi Başarılı");
                daset.Tables["kitap"].Clear();
                KitapList();
                foreach (Control item in Controls)
                {
                    if (item is TextBox)
                    {
                        item.Text = "";
                    }
                }
            }
        }

        private void btnIptal_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtBarkodAra_TextChanged(object sender, EventArgs e)
        {
            daset.Tables["kitap"].Clear();
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select * from kitap where barkodno like '%" + txtBarkodAra.Text + "%'", baglanti);
            adtr.Fill(daset, "kitap");
            dataGridView1.DataSource = daset.Tables["kitap"];
            baglanti.Close();
        }

        private void txtKitapAra_TextChanged(object sender, EventArgs e)
        {
            daset.Tables["kitap"].Clear();
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select * from kitap where kitapadı like '%" + txtKitapAra.Text + "%'", baglanti);
            adtr.Fill(daset, "kitap");
            dataGridView1.DataSource = daset.Tables["kitap"];
            baglanti.Close();
        }

        private void txtYazarAra_TextChanged(object sender, EventArgs e)
        {
            daset.Tables["kitap"].Clear();
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select * from kitap where yazar like '%" + txtYazar.Text + "%'", baglanti);
            adtr.Fill(daset, "kitap");
            dataGridView1.DataSource = daset.Tables["kitap"];
            baglanti.Close();
        }

        private void comboTürAra_SelectedIndexChanged(object sender, EventArgs e)
        {
            daset.Tables["kitap"].Clear();
            baglanti.Open();
            SqlDataAdapter adtr = new SqlDataAdapter("select * from kitap where türü like '%" + comboTür.Text + "%'", baglanti);
            adtr.Fill(daset, "kitap");
            dataGridView1.DataSource = daset.Tables["kitap"];
            baglanti.Close();
        }
        ////
        private void txtBarkod_TextChanged(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select * from kitap where barkodno like '" + txtBarkod.Text + "'", baglanti);
            SqlDataReader read = komut.ExecuteReader();
            while (read.Read())
            {
                txtKitapAd.Text = read["kitapadı"].ToString();
                txtYazar.Text = read["yazar"].ToString();
                txtEv.Text = read["yayınevi"].ToString();
                txtSayfa.Text = read["sayfasayı"].ToString();
                comboTür.Text = read["türü"].ToString();
                txtStok.Text = read["stok"].ToString();
                txtRaf.Text = read["rafno"].ToString();

            }
            baglanti.Close();
        }
        
        private void txtKitapAd_TextChanged(object sender, EventArgs e)
        {
             
        }

        private void txtYazar_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void comboTür_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
